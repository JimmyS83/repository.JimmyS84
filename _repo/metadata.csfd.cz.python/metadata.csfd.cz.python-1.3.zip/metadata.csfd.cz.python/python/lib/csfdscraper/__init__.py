# example format for scraper results
_ScraperResults = {
    'info',
    'rating',
    'available_art',
    'error',
    'warning' # not handled
}
