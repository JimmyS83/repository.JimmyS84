# Info.cz kodi plugin

Alpha release! Description will be added.

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
