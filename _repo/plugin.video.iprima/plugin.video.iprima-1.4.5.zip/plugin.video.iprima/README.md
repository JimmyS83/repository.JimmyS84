Kodi doplněk pro iPrima.cz 
===
Video doplněk pro zobrazování obsahu z archivu iPrima.cz

Autor nedistribuuje žádný obsah zobrazený tímto doplňkem. Uživatelé se zájmem o přehrávání video obsahu by měli mít aktivní předplatné na iPrima.cz