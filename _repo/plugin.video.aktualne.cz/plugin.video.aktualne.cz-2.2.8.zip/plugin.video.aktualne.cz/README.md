# Video plugin pro aktualne.cz

Tento plugin přidává podporu pro všechna videa z video.aktualne.cz. 
Je založen na kódu od Štěpána Orta pro DVTV. Původní plugin již není potřeba, protože DVTV je jedním z pořadů na aktualne.cz.
Seznam pořadů je automaticky parsován z webu, pokud se tedy objeví nový pořad, měl by automaticky fungovat.
Fanarty jsou stahovány automaticky, narozdíl od ikonek pro pořady, které jsou součástí tohoto pluginu.
