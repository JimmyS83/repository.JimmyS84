# -*- coding: utf-8 -*-

import sys
import os
import xmltv
import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs
from urllib2 import urlopen, Request, URLError
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
from bs4 import BeautifulSoup
from urllib import urlencode
import unicodedata
import time


reload(sys)
sys.setdefaultencoding('utf8')
addon = xbmcaddon.Addon(id='script.365.epg.generator')
download_path = addon.getSetting("folder")
userpath = addon.getAddonInfo('profile')
custom_channels = xbmc.translatePath("%s/custom_channels.txt" % userpath).decode('utf-8')
temp_epg = xbmc.translatePath("%s/epg.xml" % userpath).decode('utf-8')
tvg_id = xbmc.translatePath("%s/id.txt" % userpath).decode('utf-8')
n = float(addon.getSetting("epgTimeShift"))
if n > 0:
    TimeShift = " +" + str(int(n)).zfill(2) + "00"
elif n == 0:
    TimeShift = " +" + str(int(n)).zfill(2) + "00"
else:
    TimeShift = " " + str(int(n)).zfill(3) + "00"


custom_names = []
try:
    f = xbmcvfs.File(addon.getSetting("custom_names_file")).read().splitlines()
    for x in f:
        x = x.split("=")
        custom_names.append((x[0], x[1]))
    f.close()
except:
    pass


def replace_names(value):
    if addon.getSetting("custom_names") == "true":
        for v in custom_names:
            if v[0] == value:
                value = v[1]
    return value


def encode(string):
    if addon.getSetting("diacritics") == "false":
        string = unicodedata.normalize('NFKD', string.decode('utf-8')).encode('ascii', 'ignore')
    return string


def bbc():
    headers = {"Accept-Language": "cs-CZ,en-US;q=0.9", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9","Referer":"https://www.satelitnatv.sk/tv-program/bbc-earth/", "Host": "www.satelitnatv.sk", "Content-type" : "application/x-www-form-urlencoded", "origin" : "https://www.satelitnatv.sk", "except-encoding" : "gzip, deflate"}
    programmes2 = []
    now = datetime.now()
    for i in range(int(addon.getSetting("num_days_back"))*-1, int(addon.getSetting("num_days"))):
        next_day = now + timedelta(days = i)
        date = next_day.strftime("%d.%m.%Y")
        data = urlencode({'datum' : date, 'casOd' : 'cely_den', 'channel[]' : 'BBC Earth', 'channels_sub' : 'Submit'})
        req = Request("https://satelitnatv.sk/tv-program/bbc-earth/", data, headers)
        try:
            res = urlopen(req, timeout = 5).read()
        except URLError as e:
            xbmc.log('365 EPG Generator: URLError = ' + str(e.reason), xbmc.LOGERROR)
            xbmcgui.Dialog().notification("365 EPG Generator",str(e.reason), xbmcgui.NOTIFICATION_ERROR, 6000, sound = False)
            sys.exit(0)
        soup = BeautifulSoup(res, 'html.parser')
        items = soup.find_all('td',onclick=True)
        for x in items:
            name = x["onclick"].split("'")[1]
            desc = x["onclick"].split("'")[15]
            date = (x["onclick"].split("'")[13]).split(".")
            date = date[2] + date[1] + date[0]
            start_time = date + x["onclick"].split("'")[7].replace(":", "") + "00"
            stop_time = date + x["onclick"].split("'")[9].replace(":", "") + "00"
            programm = {'channel': '0-bbc-earth', 'start': start_time + TimeShift, 'stop': stop_time + TimeShift, 'title': [(name, u'')], 'desc': [(desc, u'')]}
            if programm not in programmes2:
                programmes2.append(programm)
    for x in range(0, len(programmes2)):
        try:
            programmes2[x]["stop"]  = programmes2[x + 1]["start"]
        except: pass
    return programmes2


def get_channels_list():
    f = open(tvg_id, 'w')
    channels = []
    ch = {}
    try:
        html = urlopen("http://programandroid.365dni.cz/android/v5-tv.php?locale=cs_CZ", timeout = 5).read()
    except URLError as e:
        xbmc.log('365 EPG Generator: URLError = ' + str(e.reason), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("365 EPG Generator",str(e.reason), xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
        sys.exit(0)
    root = ET.fromstring(html)
    for i in root.iter('a'):
        if addon.getSetting("category") == "0":
#            if 'c' in i.attrib:
                if i.find('p').text == "České" or i.find('p').text == "Slovenské":
                    ch[i.attrib["id"]] = encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower())
                    if addon.getSetting("logo_enabled") == "true":
                        channels.append({'display-name': [(replace_names(i.find('n').text), u'cs')], 'id': encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower()), 'icon': [{'src': 'http://portal2.sms.cz/kategorie/televize/bmp/loga/velka/' + str(i.find('o').text)}]})
                    else:
                        channels.append({'display-name': [(replace_names(i.find('n').text), u'cs')], 'id': encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower())})
        elif addon.getSetting("category") == "2":
            try:
                cch = open(custom_channels, "r").read().split(",")
            except:
                xbmcgui.Dialog().notification("365 EPG Generator","Žádné vlastní kanály", xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
                sys.exit(0)
            if i.attrib["id"] in cch:
                ch[i.attrib["id"]] = encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower())
                if addon.getSetting("logo_enabled") == "true":
                    channels.append({'display-name': [(replace_names(i.find('n').text), u'cs')], 'id': encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower()),'icon': [{'src': 'http://portal2.sms.cz/kategorie/televize/bmp/loga/velka/' + str(i.find('o').text)}]})
                else:
                    channels.append({'display-name': [(replace_names(i.find('n').text), u'cs')], 'id': encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower())})
        else:
            ch[i.attrib["id"]] = encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower())
            if addon.getSetting("logo_enabled") == "true":
                channels.append({'display-name': [(replace_names(i.find('n').text), u'cs')], 'id': encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower()),'icon': [{'src': 'http://portal2.sms.cz/kategorie/televize/bmp/loga/velka/' + str(i.find('o').text)}]})
            else:
                f.write(i.find('n').text + ': ' + 'tvg-id="' + encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower()) + '"' + '\n')
                channels.append({'display-name': [(replace_names(i.find('n').text), u'cs')], 'id': encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower())})
    f.close()
    chl = ','.join(ch.keys())
    return chl, ch, channels


def main(notice):
    try:
        cchc = open(custom_channels, "r").read().split(",")
    except:
        cchc = []
    chl, ch, channels = get_channels_list()
    programmes = []
    if chl != "":
        if notice == 1:
            xbmcgui.Dialog().notification("365 EPG Generator","Generuje se...", xbmcgui.NOTIFICATION_INFO, 3000, sound = False)
        now = datetime.now()
        for i in range(int(addon.getSetting("num_days_back"))*-1, int(addon.getSetting("num_days"))):
            next_day = now + timedelta(days = i)
            date = next_day.strftime("%Y-%m-%d")
            try:
                html = urlopen("http://programandroid.365dni.cz/android/v5-program.php?datum=" + date + "&id_tv=" + chl, timeout = 5).read()
                root = ET.fromstring(html)
                root[:] = sorted(root, key=lambda child: (child.tag,child.get('o')))
                for i in root.iter('p'):
                    n = i.find('n').text
                    try:
                        k = i.find('k').text
                    except:
                        k = ''
                    programmes.append({'channel': ch[i.attrib["id_tv"]].replace('804-ct-art', '805-ct-:d'), 'start': i.attrib["o"].replace("-", "").replace(":", "").replace(" ", "") + TimeShift, 'stop': i.attrib["d"].replace("-", "").replace(":", "").replace(" ", "") + TimeShift, 'title': [(n, u'')], 'desc': [(k, u'')]})
            except:
                pass
        if addon.getSetting("category") == "0" or addon.getSetting("category") == "1":
            if addon.getSetting("logo_enabled") == "true":
                channels.append({'display-name': [('BBC Earth', u'cs')], 'id': '0-bbc-earth','icon': [{'src': 'https://www.satelitnatv.sk//obrazky/loga_stanic/50/bbc_earth_50.png'}]})
            else:
                channels.append({'display-name': [('BBC Earth', u'cs')], 'id': '0-bbc-earth'})
            programmes2 = bbc()
            for y in programmes2:
                programmes.append(y)
        else:
            if "0" in cchc:
                if addon.getSetting("logo_enabled") == "true":
                    channels.append({'display-name': [('BBC Earth', u'cs')], 'id': '0-bbc-earth','icon': [{'src': 'https://www.satelitnatv.sk//obrazky/loga_stanic/50/bbc_earth_50.png'}]})
                else:
                    channels.append({'display-name': [('BBC Earth', u'cs')], 'id': '0-bbc-earth'})
                programmes2 = bbc()
                for y in programmes2:
                    programmes.append(y)
        w = xmltv.Writer(encoding="utf-8", source_info_url="http://www.funktronics.ca/python-xmltv", source_info_name="Funktronics", generator_info_name="python-xmltv", generator_info_url="http://www.funktronics.ca/python-xmltv")
        for c in channels:
            w.addChannel(c)
        for p in programmes:
            w.addProgramme(p)
        w.write(temp_epg, pretty_print=True)
        xbmcvfs.copy(temp_epg, download_path + addon.getSetting("file_name"))
        xbmcvfs.delete(temp_epg)
        if notice == 1:
            xbmcgui.Dialog().notification("365 EPG Generator","Hotovo, uloženo ve složce", xbmcgui.NOTIFICATION_INFO, 4000, sound = False)
        if addon.getSetting("first_start") == "true" and addon.getSetting("restart_pvr") == "true":
            try:
                xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
                time.sleep(1)
                xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":true}}')
                if addon.getSetting("play_pvr") == "true":
                    time.sleep(5)
                    if addon.getSetting("pvr_type") == "0":
                        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","params":{"action":"playpvrtv"},"id":1}')
                    else:
                        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","params":{"action":"playpvrradio"},"id":1}')
            except:
                pass
    elif "0" in cchc:
        if notice == 1:
            xbmcgui.Dialog().notification("365 EPG Generator","Generuje se...", xbmcgui.NOTIFICATION_INFO, 3000, sound = False)
        if addon.getSetting("logo_enabled") == "true":
            channels.append({'display-name': [('BBC Earth', u'cs')], 'id': '0-bbc-earth','icon': [{'src': 'https://www.satelitnatv.sk//obrazky/loga_stanic/50/bbc_earth_50.png'}]})
        else:
            channels.append({'display-name': [('BBC Earth', u'cs')], 'id': '0-bbc-earth'})
        programmes2 = bbc()
        for y in programmes2:
            programmes.append(y)
        w = xmltv.Writer(encoding="utf-8", source_info_url="http://www.funktronics.ca/python-xmltv", source_info_name="Funktronics", generator_info_name="python-xmltv", generator_info_url="http://www.funktronics.ca/python-xmltv")
        for c in channels:
            w.addChannel(c)
        for p in programmes:
            w.addProgramme(p)
        w.write(temp_epg, pretty_print=True)
        xbmcvfs.copy(temp_epg, download_path + addon.getSetting("file_name"))
        xbmcvfs.delete(temp_epg)
        if notice == 1:
            xbmcgui.Dialog().notification("365 EPG Generator","Hotovo, uloženo ve složce", xbmcgui.NOTIFICATION_INFO, 4000, sound = False)
        if addon.getSetting("first_start") == "true" and addon.getSetting("restart_pvr") == "true":
            try:
                xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
                time.sleep(1)
                xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":true}}')
                if addon.getSetting("play_pvr") == "true":
                    time.sleep(5)
                    if addon.getSetting("pvr_type") == "0":
                        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","params":{"action":"playpvrtv"},"id":1}')
                    else:
                        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","params":{"action":"playpvrradio"},"id":1}')
            except:
                pass
    else:
        xbmcgui.Dialog().notification("365 EPG Generator","Žádné vlastní kanály", xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
    addon.setSetting("first_start", "false")
    sys.modules.clear()


def router():
    paramstring = sys.argv[0]
    if paramstring == "main.py":
        if addon.getSetting("notice") == "true":
            main(1)
        else:
            main(0)
    else:
        main(1)


if __name__ == '__main__':
    router()