# -*- coding: utf-8 -*-


import xbmcaddon
import xbmcgui
import xbmc
import unicodedata
from urllib2 import urlopen
import xml.etree.ElementTree as ET


reload(sys)
sys.setdefaultencoding('utf8')
addon = xbmcaddon.Addon(id='script.365.epg.generator')


def encode(string):
    if addon.getSetting("diacritics") == "false":
        string = unicodedata.normalize('NFKD', string.decode('utf-8')).encode('ascii', 'ignore')
    return "[COLOR lightskyblue]" + string + "[/COLOR]"


def main():
    channels = []
    channels.append("BBC Earth: [COLOR lightskyblue]0-bbc-earth[/COLOR]")
    html = urlopen("http://programandroid.365dni.cz/android/v5-tv.php?locale=cs_CZ").read()
    root = ET.fromstring(html)
    for i in root.iter('a'):
        channels.append(i.find('n').text + ": " + encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower()))
    text = "\n\n".join(channels)
    xbmcgui.Dialog().textviewer("Seznam tvg-id kanálů", text)


if __name__ == "__main__":
    main()