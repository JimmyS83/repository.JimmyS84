# plugin.video.mall.tv

Video doplněk do [kodi](http://www.kodi.tv/) verze 19+ pro přehrávání videí z české a slovenské internetové televize [mall.tv](https://www.mall.tv/).

Informace o instalaci najdete na stránkách repozitáře [Kodi CZ/SK](http://kodi-czsk.github.io/repository/).
