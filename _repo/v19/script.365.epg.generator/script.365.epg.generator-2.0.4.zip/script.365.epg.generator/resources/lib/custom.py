# -*- coding: utf-8 -*-

import sys
import os
import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs
import json
import requests
import xml.etree.ElementTree as ET


addon = xbmcaddon.Addon(id='script.365.epg.generator')
userpath = addon.getAddonInfo('profile')
custom_channels = xbmcvfs.translatePath("%s/custom_channels.txt" % userpath)
custom_channels_tm = xbmcvfs.translatePath("%s/custom_channels_tm.txt" % userpath)
channels_select_path = xbmcvfs.translatePath(userpath + "/channels.json")


def select():
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    category = {"České": "CZ", "Slovenské": "SK", "Polské": "PL", "Německé": "DE", "Anglické": "EN", "Francouzské": "FR", "Maďarské": "HU", "Ruské": "RU", "Španělské": "ES", "Italské": "IT", "Ostatní": "", "T-Mobile TV GO": "TM"}
    if category[sys.argv[1]] == "TM":
        tm_channels = {"BBC Earth": "4495", "Digi Sport 6": "4446", "Digi Sport 7": "4447", "Digi Sport 8": "4448", "Digi Sport 9": "4449"}
        channels = list(tm_channels.keys())
        sorted(channels)
    else:
        channels = []
        html = requests.get("http://programandroid.365dni.cz/android/v6-tv.php?locale=cs_CZ").text
        root = ET.fromstring(html)
        for i in root.iter('a'):
            if i.attrib["c"] == category[sys.argv[1]]:
                channels.append(i.find('n').text)
    if os.path.exists(channels_select_path):
        f = open(channels_select_path, "r").read()
        data = json.loads(f)
        try:
            ch = data[sys.argv[1].encode().decode("utf-8")][0]
            ch_preselect = []
            for i in ch:
                ch_preselect.append(channels.index(i))
        except:
            ch_preselect = []
    else:
        ch_preselect = []
        data = {}
    repair_channels = []
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    dialog = xbmcgui.Dialog()
    types = dialog.multiselect(sys.argv[1], channels, preselect=ch_preselect)
    if types is None:
        pass
    else:
        for index in types:
            repair_channels.append(channels[index])
        select_channels = []
        if category[sys.argv[1]] == "TM":
            for key, value in tm_channels.items():
                if key in repair_channels:
                    select_channels.append(value)
        else:
            for i in root.iter('a'):
                if i.find('n').text in repair_channels:
                    select_channels.append(i.attrib["id"])
        ff = open(channels_select_path, "w")
        data[sys.argv[1].encode().decode("utf-8")] = [repair_channels, ",".join(select_channels)]
        json.dump(data, ff)
        ff.close()
        if category[sys.argv[1]] == "TM":
            c_path = custom_channels_tm
            id = data["T-Mobile TV GO"][1]
        else:
            c_path = custom_channels
            id = []
            for key, value in data.items():
                if key != "T-Mobile TV GO":
                    if value[1] != "":
                        id.append(value[1])
            id = ",".join(id)
        fff = open(c_path, "w")
        fff.write(id)
        fff.close()


if __name__ == "__main__":
    select()