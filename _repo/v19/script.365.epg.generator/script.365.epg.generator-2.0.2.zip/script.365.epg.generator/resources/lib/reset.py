# -*- coding: utf-8 -*-

import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui

addon = xbmcaddon.Addon(id='script.365.epg.generator')
userpath = addon.getAddonInfo('profile')
custom_channels = xbmc.translatePath("%s/custom_channels.txt" % userpath)
custom_channels_tm = xbmc.translatePath("%s/custom_channels_tm.txt" % userpath)
channels_select_path = xbmc.translatePath("%s/channels.json" % userpath)

try:
    xbmcvfs.delete(custom_channels)
except:
    pass
try:
    xbmcvfs.delete(custom_channels_tm)
except:
    pass
try:
    xbmcvfs.delete(channels_select_path)
except:
    pass
xbmcgui.Dialog().notification("365 EPG Generator","Obnoveno", xbmcgui.NOTIFICATION_INFO, 1000, sound = False)
