# -*- coding: utf-8 -*-

import sys
import os
import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
import unicodedata
import time
import requests
try:
    from resources.lib import xmltv
except:
    import xmltv


addon = xbmcaddon.Addon(id='script.365.epg.generator')
download_path = addon.getSetting("folder")
userpath = addon.getAddonInfo('profile')
custom_channels = xbmc.translatePath("%s/custom_channels.txt" % userpath)
custom_channels_tm = xbmc.translatePath("%s/custom_channels_tm.txt" % userpath)
channels_select_path = xbmc.translatePath(userpath + "/channels.json")
temp_epg = xbmc.translatePath("%s/epg.xml" % userpath)
custom_names_path = xbmc.translatePath("%s/custom_names.txt" % userpath)
n = float(addon.getSetting("epgTimeShift"))
if n > 0:
    TimeShift = " +" + str(int(n)).zfill(2) + "00"
elif n == 0:
    TimeShift = " +" + str(int(n)).zfill(2) + "00"
else:
    TimeShift = " " + str(int(n)).zfill(3) + "00"


custom_names = []
dialog = xbmcgui.DialogProgressBG()
if addon.getSetting("notice") == "true" and addon.getSetting("dialog") == "true":
    dialog.create("365 EPG Generator","Stahování dat...")
    DLG = True
else:
    DLG = False


try:
    f = open(custom_names_path, "r", encoding="utf-8").read().splitlines()
    for x in f:
        x = x.split("=")
        custom_names.append((x[0], x[1]))
except:
    pass


if addon.getSetting("custom_names") == "true":
    CN = True
else:
    CN = False
if addon.getSetting("diacritics") == "false":
    DC = False
else:
    DC = True


def replace_names(value):
    if CN == True:
        for v in custom_names:
            if v[0] == value:
                value = v[1]
    return value


def encode(string):
    if DC == False:
        string = str(unicodedata.normalize('NFKD', string).encode('ascii', 'ignore'), "utf-8")
    return string


def notice(text, type):
    if addon.getSetting("notice") == "true" and addon.getSetting("dialog") == "false":
        if type == 0:
            xbmcgui.Dialog().notification("365 EPG Generator",text, xbmcgui.NOTIFICATION_INFO, 4000, sound = False)
        else:
            xbmcgui.Dialog().notification("365 EPG Generator",text, xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)


def restart_pvr():
    if addon.getSetting("restart_pvr") == "true":
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
        time.sleep(2)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":true}}')
        if addon.getSetting("play_pvr") == "true":
            time.sleep(5)
            if addon.getSetting("pvr_type") == "0":
                xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","params":{"action":"playpvrtv"},"id":1}')
            else:
                xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","params":{"action":"playpvrradio"},"id":1}')


def get_tm_programmes(tm):
    programmes2 = []
    tvch = {"BBC Earth HD": "0-bbc-earth", "Digi Sport 6 HD": "3006-digi-sport-6", "Digi Sport 7 HD": "3007-digi-sport-7", "Digi Sport 8 HD": "3008-digi-sport-8", "Digi Sport 9 HD": "3009-digi-sport-9"}
    params={"dsid": "c75536831e9bdc93", "deviceName": "Redmi%20Note%207", "deviceType": "OTT_ANDROID", "osVersion": "10", "appVersion": "3.7.0", "language": "CZ"}
    headers={"Host": "czgo.magio.tv", "authorization": "Bearer", "User-Agent": "okhttp/3.12.12", "content-type":  "application/json"}
    req = requests.post("https://czgo.magio.tv/v2/auth/init", params=params, headers=headers).json()
    token = req["token"]["accessToken"]
    headers={"Host": "czgo.magio.tv", "authorization": "Bearer " + token, "User-Agent": "okhttp/3.12.12", "content-type":  "application/json"}
    now = datetime.now()
    back_day = now + timedelta(days = int(addon.getSetting("num_days_back"))*-1)
    next_day = now + timedelta(days = int(addon.getSetting("num_days")))
    date_from = back_day.strftime("%Y-%m-%d")
    date_to = next_day.strftime("%Y-%m-%d")
    req = requests.get("https://czgo.magio.tv/v2/television/epg?filter=channel.id=in=(" + tm + ");endTime=ge=" + date_from + "T00:00:00.000Z;startTime=le=" + date_to + "T00:59:59.999Z&limit=20&offset=0&lang=CZ", headers=headers).json()["items"]
    for x in range(0, len(req)):
        for y in req[x]["programs"]:
            channel = y["channel"]["name"]
            start_time = y["startTime"].replace("-", "").replace("T", "").replace(":", "")
            stop_time = y["endTime"].replace("-", "").replace("T", "").replace(":", "")
            title = y["program"]["title"]
            desc = y["program"]["description"]
            epi = y["program"]["programValue"]["episodeId"]
            if epi != None:
                title = title + " (" + epi + ")"
            programm = {'channel': tvch[channel], 'start': start_time + TimeShift, 'stop': stop_time + TimeShift, 'title': [(title, u'')], 'desc': [(desc, u'')]}
            if programm not in programmes2:
                programmes2.append(programm)
    return programmes2


class Get_channels:

    def __init__(self):
        self.channels = []
        self.html = requests.get("http://programandroid.365dni.cz/android/v6-tv.php?locale=cs_CZ").text
        self.ch = {}

    def all_channels(self):
        try:
            root = ET.fromstring(self.html)
            for i in root.iter("a"):
                self.ch[i.attrib["id"]] = encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower())
                self.channels.append({"display-name": [(replace_names(i.find("n").text), u"cs")], "id": encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower()), "icon": [{"src": "http://portal2.sms.cz/kategorie/televize/bmp/loga/velka/" + i.find("o").text}]})
        except:
            pass
        return self.ch, self.channels

    def cz_sk_channels(self):
        try:
            root = ET.fromstring(self.html)
            for i in root.iter("a"):
                if i.find("p").text == "České" or i.find("p").text == "Slovenské":
                    self.ch[i.attrib["id"]] = encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower())
                    self.channels.append({"display-name": [(replace_names(i.find("n").text), u"cs")], "id": encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower()), "icon": [{"src": "http://portal2.sms.cz/kategorie/televize/bmp/loga/velka/" + i.find("o").text}]})
        except:
            pass
        return self.ch, self.channels

    def own_channels(self, cchc):
        try:
            root = ET.fromstring(self.html)
            for i in root.iter("a"):
                if i.attrib["id"] in cchc:
                    self.ch[i.attrib["id"]] = encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower())
                    self.channels.append({"display-name": [(replace_names(i.find("n").text), u"cs")], "id": encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower()), "icon": [{"src": "http://portal2.sms.cz/kategorie/televize/bmp/loga/velka/" + i.find("o").text}]})
        except:
            pass
        return self.ch, self.channels


class Get_programmes:

    def __init__(self, days_back, days, tm):
        self.programmes = []
        self.days_back = days_back
        self.days = days
        if tm != "":
            programmes2 = get_tm_programmes(tm)
            for y in programmes2:
                self.programmes.append(y)

    def data_programmes(self, cht, ch):
        if ch != {}:
            chl = ",".join(ch.keys())
            now = datetime.now()
            st = 1
            for i in range(self.days_back*-1, self.days):
                next_day = now + timedelta(days = i)
                date = next_day.strftime("%Y-%m-%d")
                date_ = next_day.strftime("%d.%m.%Y")
                html = requests.get("http://programandroid.365dni.cz/android/v6-program.php?datum=" + date + "&id_tv=" + chl).text
                root = ET.fromstring(html)
                root[:] = sorted(root, key=lambda child: (child.tag,child.get("o")))
                for i in root.iter("p"):
                    n = i.find("n").text
                    try:
                        k = i.find("k").text
                    except:
                        k = ""
                    if i.attrib["id_tv"] in ch:
                        self.programmes.append({"channel": ch[i.attrib["id_tv"]].replace("804-ct-art", "805-ct-:d"), "start": i.attrib["o"].replace("-", "").replace(":", "").replace(" ", "") + TimeShift, "stop": i.attrib["d"].replace("-", "").replace(":", "").replace(" ", "") + TimeShift, "title": [(n, "")], "desc": [(k, "")]})
                per = int(int(addon.getSetting("num_days_back")) + int(addon.getSetting("num_days")))
                percent = int((float(st*100) / per))
                if DLG == True:
                    dialog.update(percent, cht, date_)
                st += 1
        return self.programmes


def generator():
    notice("Generuje se...", 0)
    cchc = ""
    tm_id = ""
    channels_type = addon.getSetting("category")
    days = int(addon.getSetting("num_days"))
    days_back = int(addon.getSetting("num_days_back"))
    if channels_type == "1":
        cht = "Všechny kanály"
        tm_id = "4495,4446,4447,4448,4449"
        g = Get_channels()
        ch, channels = g.all_channels()
        channels.extend(({"display-name": [(replace_names("BBC Earth"), u"cs")], "id": "0-bbc-earth", "icon": [{"src": "https://files.cdn.magio.tv/tv_logos/bbc-earth-hd.png"}]}, {"display-name": [(replace_names("Digi Sport 6"), u"cs")], "id": "3006-digi-sport-6", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-6-hd.png'}]}, {"display-name": [(replace_names("Digi Sport 7"), u"cs")], "id": "3007-digi-sport-7", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-7-hd.png'}]}, {"display-name": [(replace_names("Digi Sport 8"), u"cs")], "id": "3008-digi-sport-8", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-8-hd.png'}]}, {"display-name": [(replace_names("Digi Sport 9"), u"cs")], "id": "3009-digi-sport-9", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-9-hd.png'}]}))
    elif channels_type == "0":
        cht = "Cz/Sk kanály"
        tm_id = "4495,4446,4447,4448,4449"
        g = Get_channels()
        ch, channels = g.cz_sk_channels()
        channels.extend(({"display-name": [(replace_names("BBC Earth"), u"cs")], "id": "0-bbc-earth", "icon": [{"src": "https://files.cdn.magio.tv/tv_logos/bbc-earth-hd.png"}]}, {"display-name": [(replace_names("Digi Sport 6"), u"cs")], "id": "3006-digi-sport-6", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-6-hd.png'}]}, {"display-name": [(replace_names("Digi Sport 7"), u"cs")], "id": "3007-digi-sport-7", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-7-hd.png'}]}, {"display-name": [(replace_names("Digi Sport 8"), u"cs")], "id": "3008-digi-sport-8", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-8-hd.png'}]}, {"display-name": [(replace_names("Digi Sport 9"), u"cs")], "id": "3009-digi-sport-9", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-9-hd.png'}]}))
    elif channels_type == "2":
        ch, channels = {}, []
        cht = "Vlastní kanály"
        if os.path.exists(custom_channels):
            cchc = open(custom_channels).read()
            if cchc != "":
                g = Get_channels()
                cchc = cchc.split(",")
                ch, channels = g.own_channels(cchc)
        if os.path.exists(custom_channels_tm):
            tm_id = open(custom_channels_tm).read()
            if tm_id != "":
                tm_id_list = tm_id.split(",")
                if "4495" in tm_id_list:
                    channels.append({"display-name": [(replace_names("BBC Earth"), u"cs")], "id": "0-bbc-earth", "icon": [{"src": "https://files.cdn.magio.tv/tv_logos/bbc-earth-hd.png"}]})
                if "4446" in tm_id_list:
                    channels.append({"display-name": [(replace_names("Digi Sport 6"), u"cs")], "id": "3006-digi-sport-6", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-6-hd.png'}]})
                if "4447" in tm_id_list:
                    channels.append({"display-name": [(replace_names("Digi Sport 7"), u"cs")], "id": "3007-digi-sport-7", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-7-hd.png'}]})
                if "4448" in tm_id_list:
                    channels.append({"display-name": [(replace_names("Digi Sport 8"), u"cs")], "id": "3008-digi-sport-8", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-8-hd.png'}]})
                if "4449" in tm_id_list:
                    channels.append({"display-name": [(replace_names("Digi Sport 9"), u"cs")], "id": "3009-digi-sport-9", "icon": [{"src": 'https://files.cdn.magio.tv/tv_logos/digi-sport-9-hd.png'}]})
    if channels != []:
        gg = Get_programmes(days_back, days, tm_id)
        programmes = gg.data_programmes(cht, ch)
        if programmes != []:
            w = xmltv.Writer(encoding="utf-8", source_info_url="http://www.funktronics.ca/python-xmltv", source_info_name="Funktronics", generator_info_name="python-xmltv", generator_info_url="http://www.funktronics.ca/python-xmltv")
            stch = 1
            for c in channels:
                w.addChannel(c)
                per = len(channels)
                percent = int((float(stch*100) / per))
                if DLG == True:
                    dialog.update(percent, cht, c["display-name"][0][0])
                stch += 1
            stch = 1
            for p in programmes:
                w.addProgramme(p)
                per = len(programmes)
                percent = int((float(stch*100) / per))
                if DLG == True:
                    dialog.update(percent, cht, p["channel"])
                stch += 1
            if DLG == True:
                dialog.update(0, "365 EPG Generator", "Ukládání...")
            w.write(temp_epg, pretty_print=True)
            xbmcvfs.copy(temp_epg, download_path + addon.getSetting("file_name"))
            xbmcvfs.delete(temp_epg)
            if DLG == True:
                dialog.update(100, "365 EPG Generator", "Hotovo")
            time.sleep(0.5)
            dialog.close()
            notice("Hotovo, uloženo ve složce", 0)
            if sys.argv[0] == "start.py":
                restart_pvr()
        else:
            notice("Žádná data", 1)
    else:
        notice("Žádné vlastní kanály", 1)