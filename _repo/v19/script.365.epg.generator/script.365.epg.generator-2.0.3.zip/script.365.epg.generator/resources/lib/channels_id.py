# -*- coding: utf-8 -*-


import xbmcaddon
import xbmcgui
import xbmc
import unicodedata
import requests
import xml.etree.ElementTree as ET


addon = xbmcaddon.Addon(id='script.365.epg.generator')


def encode(string):
    if addon.getSetting("diacritics") == "false":
        string = str(unicodedata.normalize('NFKD', string).encode('ascii', 'ignore'), "utf-8")
    return '[COLOR lightskyblue]' + string + '[/COLOR]'


def main():
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    channels = ["BBC Earth: [COLOR lightskyblue]0-bbc-earth[/COLOR]", "Digi Sport 6: [COLOR lightskyblue]3006-digi-sport-6[/COLOR]", "Digi Sport 7: [COLOR lightskyblue]3007-digi-sport-7[/COLOR]", "Digi Sport 8: [COLOR lightskyblue]3008-digi-sport-8[/COLOR]", "Digi Sport 9: [COLOR lightskyblue]3009-digi-sport-9[/COLOR]"]
    html = requests.get("http://programandroid.365dni.cz/android/v6-tv.php?locale=cs_CZ").text
    root = ET.fromstring(html)
    for i in root.iter('a'):
        channels.append(i.find('n').text + ": " + encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower()))
    text = "\n\n".join(channels)
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    xbmcgui.Dialog().textviewer("Seznam tvg-id kanálů", text)


if __name__ == "__main__":
    main()