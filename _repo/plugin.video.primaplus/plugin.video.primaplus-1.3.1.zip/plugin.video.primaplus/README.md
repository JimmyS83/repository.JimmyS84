<h1>Prima+</h1>
<p>
<h3>Kodi doplňek pro Prima+</h3>
<p>
Pro fungování doplňku je potřeba mít registraci s minimálně Free tarifem na www.iprima.cz.<br><br>
<a href="https://www.xbmc-kodi.cz/prima-+">Vlákno na fóru XBMC-Kodi.cz</a><br><br>

v1.3.1 (9.7.2024)<br>
- ošetření chybějícího EPG<br><br>

v1.3.0 (9.7.2024)<br>
- přepracované živé vysílání a archiv<br><br>

v1.2.5 (2.6.2024)<br>
- ošetření Fairplay DRM u HLS<br><br>

v1.2.4 (1.5.2024)<br>
- úprava parametru pro ISA v Kodi Leia (od roomie)<br><br>

v1.2.3 (16.1.2024)<br>
- oprava chyby při spuštění doplňku<br><br>
</p>
