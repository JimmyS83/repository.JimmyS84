# plugin.video.dokumenty.tv
kodi plugin pre dokumenty.tv
tazka alfa verzia
vyzaduje: script.module.resolveurl, script.module.urlresolver

odporucam pridat si do kodi tuto repo
https://github.com/tvaddonsco/tva-resolvers-repo/tree/master/zips/repository.tva.common
