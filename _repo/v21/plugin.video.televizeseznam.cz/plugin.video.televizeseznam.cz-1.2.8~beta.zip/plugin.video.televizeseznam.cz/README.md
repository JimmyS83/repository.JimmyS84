# Stream

Video doplněk do [Kodi](http://www.kodi.tv/) pro přehrávání videí ze [Stream](https://www.stream.cz).
