<h1>Prima+</h1>
<p>
<h3>Kodi doplňek pro Prima+</h3>
<p>
Pro fungování doplňku je potřeba mít registraci s minimálně Free tarifem na www.iprima.cz.<br><br>
<a href="https://www.xbmc-kodi.cz/prima-+">Vlákno na fóru XBMC-Kodi.cz</a><br><br>
v1.2.4 (1.5.2024)<br>
- úprava parametru pro ISA v Kodi Leia (od roomie)<br><br>

v1.2.3 (16.1.2024)<br>
- oprava chyby při spuštění doplňku<br><br>

v1.2.2 (12.1.2024)<br>
- přidána správa zařízení<br><br>

v1.2.1 (11.1.2024)<br>
- registrace zařízení<br>
- možnost resetu zařízení<br>
- úprava kešovaní seznamů<br><br>

v1.2.0 (8.1.2024)<br>
- přehrávání streamů s DRM<br>
- možnost zapnout logování<br><br>
</p>
