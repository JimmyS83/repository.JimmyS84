# TV Nova (Nova Plus)

Video doplněk do [Kodi](http://www.kodi.tv/) pro přehrávání videí z [TV Nova.cz](https://www.nova.cz/).
