# Nova Plus
Video doplněk do [Kodi](http://www.kodi.tv/) pro přehrávání videí z [NovaPlus.cz](https://www.novaplus.cz/).
